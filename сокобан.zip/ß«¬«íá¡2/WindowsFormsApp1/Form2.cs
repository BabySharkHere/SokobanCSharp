﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form2 : Form
    {
        //Player currentPlayer;
        Thread th;
        private static int size;
        static int height = 0;
        static int width = 0;
        int[,] map;
        int currentX = 0;
        int currentY = 0;
        int saveX = 0;
        int saveY = 0;
        private int greenCases = 0;
        private int greyCases = 0;
        int nastGreen = 0;
        int kolvoSteps = 0;
        int[] record;
        public static string path = "";
        string pathToRecord = @"record.txt";

        static string pathToWall = @"textures\wall.jpg";
        static string pathToGreyCase = @"textures\greyCase.png";
        static string pathToFloor = @"textures\floor.png";
        static string pathToPlayer = @"textures\player.png";
        static string pathToGreenCase = @"textures\greenCase.png";
        static Image wall = new Bitmap(pathToWall);
        static Image greyCase = new Bitmap(pathToGreyCase);
        static Image floor = new Bitmap(pathToFloor);
        static Image player = new Bitmap(pathToPlayer);
        static Image greenCase = new Bitmap(pathToGreenCase);
        TextureBrush tBrush = new TextureBrush(wall);
        TextureBrush tBrushGreyCase = new TextureBrush(greyCase);
        TextureBrush tBrushFloor = new TextureBrush(floor);
        TextureBrush tBrushPlayer = new TextureBrush(player);
        TextureBrush tBrushGreenCase = new TextureBrush(greenCase);

        public void loadLvl()
        {
            if (path == @"Lvl\Lvl2.txt")
            {
                this.Height = 700;
            }

            if(path == @"Lvl\Lvl3.txt")
            {
                this.Height = 700;
                this.Width = 1400;
            }

            if (path == @"Lvl\Lvl4.txt")
            {
                this.Height = 500;
            }
            StreamReader file = new StreamReader(path);
            string s = file.ReadToEnd();
            file.Close();
            string[] str = s.Split('\n');
            string[] stolb = str[0].Split(' ');
            int t = 0;
            height = str.Length;
            width = stolb.Length;
            map = new int[height, width];
            for (int i = 0; i < str.Length; i++)
            {
                stolb = str[i].Split(' ');
                for (int j = 0; j < stolb.Length; j++)
                {
                    t = Convert.ToInt32(stolb[j]);
                    map[i, j] = t;
                }
            }

            file = new StreamReader(pathToRecord);
            s = file.ReadToEnd();
            file.Close();
            stolb = s.Split('\n');
            record = new int[stolb.Length-1];
            for(int i = 0; i < stolb.Length-1; i++)
            {
                t = Convert.ToInt32(stolb[i]);
                record[i] = t;
            }
        }

        public Form2()
        {
            this.KeyUp += new KeyEventHandler(keyFunc);
            this.DoubleBuffered = true;
            InitializeComponent();
            Init();
        }

        public void Init()
        {
            KeyPreview = true;
            size = 50;
            //currentPlayer = new Player(currentX,currentY);
            loadLvl();
            findStartPos(map, 1);
            greenCases = findElement(map, 4);
            greyCases = findElement(map, 3);
            nastGreen = 0;
            kolvoSteps = 0;
            textBoxUpdate(greyCases, greenCases, kolvoSteps);
            Invalidate();
            
        }

        private void keyFunc(object sender, KeyEventArgs e)
        {
            e.Handled = true;
            switch (e.KeyCode)
            {
                case Keys.W:
                    {
                        saveX = currentX;
                        saveY = currentY;
                        moveUp();
                        kolvoSteps++;
                        textBoxUpdate(greenCases, greyCases, kolvoSteps);
                        Invalidate();
                        break;
                    }
                case Keys.S:
                    {
                        saveX = currentX;
                        saveY = currentY;
                        moveDown();
                        kolvoSteps++;
                        textBoxUpdate(greenCases, greyCases, kolvoSteps);
                        Invalidate();
                        break;
                    }
                case Keys.A:
                    {
                        saveX = currentX;
                        saveY = currentY;
                        moveLeft();
                        kolvoSteps++;
                        textBoxUpdate(greenCases, greyCases, kolvoSteps);
                        Invalidate();
                        break;
                    }
                case Keys.D:
                    {
                        saveX = currentX;
                        saveY = currentY;
                        moveRight();
                        kolvoSteps++;
                        textBoxUpdate(greenCases, greyCases, kolvoSteps);
                        Invalidate();
                        break;
                    }
                //case Keys.Space:
                //    {
                //        map[currentX, currentY] = 0;
                //        currentX = saveX;
                //        currentY = saveY;
                //        map[currentX, currentY] = 1;
                //        Invalidate();
                //        break;
                //    }
            }
        }

        public void moveUp()
        {
            if (currentX > 0)
            {
                if (map[currentX-1,currentY] != 2) 
                {
                    if (map[currentX-1,currentY] == 3)
                    {
                        if (map[currentX-2, currentY] == 4)
                        {
                            currentX--;
                            map[currentX, currentY] = 1;
                            map[currentX - 1, currentY] = 4;
                            map[currentX + 1, currentY] = 0;
                            greyCases--;
                            textBoxUpdate(greyCases, greenCases, kolvoSteps);
                        }
                        else
                            if (map[currentX - 2, currentY] != 2 && map[currentX - 2, currentY] != 3)
                            {
                                currentX--;
                                map[currentX, currentY] = 1;
                                map[currentX - 1, currentY] = 3;
                                map[currentX + 1, currentY] = 0;
                            }
                    }
                    else 
                    {
                        if (nastGreen == 1)
                        {
                            nastGreen--;
                            currentX--;
                            map[currentX, currentY] = 1;
                            map[currentX + 1, currentY] = 4;
                        }
                        else if (map[currentX - 1, currentY] == 4)
                        {
                            currentX--;
                            map[currentX, currentY] = 1;
                            map[currentX + 1, currentY] = 0;
                            nastGreen++;
                        }
                        else
                        {
                            currentX--;
                            map[currentX, currentY] = 1;
                            map[currentX + 1, currentY] = 0;
                        }
                        
                    }
                }
            }  
        }

        public void moveDown()
        {
            if (currentX < height - 1)
            {
                if (map[currentX + 1, currentY] != 2)
                {
                    if (map[currentX + 1, currentY] == 3)
                    {   
                        if(map[currentX+2, currentY] == 4)
                        {
                            currentX++;
                            map[currentX, currentY] = 1;
                            map[currentX + 1, currentY] = 4;
                            map[currentX - 1, currentY] = 0;
                            greyCases--;
                            textBoxUpdate(greyCases, greenCases, kolvoSteps);
                        }
                        else if (map[currentX + 2, currentY] != 2 && map[currentX+2, currentY] != 3)
                        {
                            currentX++;
                            map[currentX, currentY] = 1;
                            map[currentX + 1, currentY] = 3;
                            map[currentX - 1, currentY] = 0;
                        }
                    }
                    else
                    {
                        if (nastGreen == 1)
                        {
                            nastGreen--;
                            currentX++;
                            map[currentX, currentY] = 1;
                            map[currentX - 1, currentY] = 4;
                        }
                        else if (map[currentX + 1, currentY] == 4)
                        {
                            currentX++;
                            map[currentX, currentY] = 1;
                            map[currentX - 1, currentY] = 0;
                            nastGreen++;
                        }
                        else
                        {
                            currentX++;
                            map[currentX, currentY] = 1;
                            map[currentX - 1, currentY] = 0;
                        }
                    }
                }
            }
            else { 
            }
        }

        public void moveLeft()
        {
            if (currentY > 0)
            {
                if (map[currentX, currentY - 1] != 2)
                {
                    if(map[currentX, currentY-1] == 3)
                    {
                        if (map[currentX, currentY - 2] == 4)
                        {
                            currentY--;
                            map[currentX, currentY] = 1;
                            map[currentX, currentY - 1] = 4;
                            map[currentX, currentY + 1] = 0;
                            greyCases--;
                            textBoxUpdate(greyCases, greenCases, kolvoSteps);
                        }
                        else if (map[currentX, currentY - 2] != 2 && map[currentX, currentY-2] != 3)
                            {
                                currentY--;
                                map[currentX, currentY] = 1;
                                map[currentX, currentY - 1] = 3;
                                map[currentX, currentY + 1] = 0;
                            }
                      
                    }
                    else
                    {
                        if(nastGreen == 1)
                        {
                            nastGreen--;
                            currentY--;
                            map[currentX, currentY] = 1;
                            map[currentX, currentY + 1] = 4;
                        }
                        else if (map[currentX, currentY - 1] == 4)
                        {
                            currentY--;
                            map[currentX, currentY] = 1;
                            map[currentX, currentY + 1] = 0;
                            nastGreen++;
                        }
                        else
                        {
                            currentY--;
                            map[currentX, currentY] = 1;
                            map[currentX, currentY + 1] = 0;
                        }

                    }
                }
            }
            else {
                
            }
        }

        public void moveRight()
        {
            if (currentY < width-1)
            {
                if (map[currentX, currentY + 1] != 2)
                {
                    if(map[currentX, currentY+1] == 3)
                    {
                        if(map[currentX,currentY+2] == 4)
                        {
                            currentY++;
                            map[currentX, currentY] = 1;
                            map[currentX, currentY + 1] = 4;
                            map[currentX, currentY - 1] = 0;
                            greyCases--;
                            textBoxUpdate(greyCases, greenCases, kolvoSteps);
                        }
                        else if (map[currentX, currentY+2] != 2 && map[currentX,currentY+2] != 3)
                        {
                            currentY++;
                            map[currentX, currentY] = 1;
                            map[currentX, currentY + 1] = 3;
                            map[currentX, currentY - 1] = 0;
                        }
                    }
                    else 
                    {
                        if (nastGreen == 1)
                        {
                            nastGreen--;
                            currentY++;
                            map[currentX, currentY] = 1;
                            map[currentX, currentY - 1] = 4;
                        }
                        else if (map[currentX, currentY + 1] == 4)
                        {
                            currentY++;
                            map[currentX, currentY] = 1;
                            map[currentX, currentY - 1] = 0;
                            nastGreen++;
                        }
                        else
                        {
                            currentY++;
                            map[currentX, currentY] = 1;
                            map[currentX, currentY - 1] = 0;
                        }
                    }
                }
            }
            else { 
            
            }
        }

        public void textBoxUpdate(int grey, int green, int kolVo)
        {
            richTextBox1.Clear();
            richTextBox1.Text = richTextBox1.Text + "На карте осталось:\n";
            richTextBox1.Text = richTextBox1.Text + "Камней: " + grey + "\n";
            richTextBox1.Text = richTextBox1.Text + "Точек: " + green + "\n";
            richTextBox1.Text = richTextBox1.Text + "Количество шагов: " + kolVo;
        }
        //public void DrawMap(Graphics e)
        //{
        //    for(int i = 0; i < height; i++)
        //    {
        //        for (int j = 0; j < width; j++)
        //        {
        //            if (map[i, j] == 1)
        //            {
        //                e.FillRectangle(Brushes.Red, new Rectangle(50+j*size, 50+i*size, size, size));
        //            }
        //            else if (map[i,j] == 2)
        //            {
        //                e.FillRectangle(Brushes.Black, new Rectangle(50 + j * size, 50 + i * size, size, size));
        //            }
        //            else if (map[i,j] == 3)
        //            {
        //                e.FillRectangle(Brushes.Gray, new Rectangle(50 + j * size, 50 + i * size, size, size));
        //            }
        //            else if (map[i,j] == 4)
        //            {
        //                e.FillRectangle(Brushes.Green, new Rectangle(50 + j * size, 50 + i * size, size, size));
        //            }
        //        }
        //    }
        //        if (greyCases == 0)
        //        {
        //            buttonToMainMenu.Visible = true;
        //        }
        //}
        public void DrawMap(Graphics e)
        {
            //string pathToWall = @"textures\wall.jpg";
            //string pathToGreyCase = @"textures\greyCase.png";
            //string pathToFloor = @"textures\floor.png";
            //string pathToPlayer = @"textures\player.png";
            //string pathToGreenCase = @"textures\greenCase.png";
            //Image wall = new Bitmap(pathToWall);
            //Image greyCase = new Bitmap(pathToGreyCase);
            //Image floor = new Bitmap(pathToFloor);
            //Image player = new Bitmap(pathToPlayer);
            //Image greenCase = new Bitmap(pathToGreenCase);
            //TextureBrush tBrush = new TextureBrush(wall);
            //TextureBrush tBrushGreyCase = new TextureBrush(greyCase);
            //TextureBrush tBrushFloor = new TextureBrush(floor);
            //TextureBrush tBrushPlayer = new TextureBrush(player);
            //TextureBrush tBrushGreenCase = new TextureBrush(greenCase);

            for (int i = 0; i < height; i++)
            {
                for (int j = 0; j < width; j++)
                {
                    if (map[i, j] == 1)
                    {
                        //e.FillRectangle(Brushes.Red, new Rectangle(50 + j * size, 50 + i * size, size, size));
                        e.FillRectangle(tBrushPlayer, new Rectangle(50 + j * size, 50 + i * size, size, size));
                    }
                    else if (map[i, j] == 2)
                    {
                        //e.FillRectangle(Brushes.Black, new Rectangle(50 + j * size, 50 + i * size, size, size));
                        e.FillRectangle(tBrush, new Rectangle(50 + j * size, 50 + i * size, size, size));
                    }
                    else if (map[i, j] == 3)
                    {
                        //e.FillRectangle(Brushes.Gray, new Rectangle(50 + j * size, 50 + i * size, size, size));
                        e.FillRectangle(tBrushGreyCase, new Rectangle(50 + j * size, 50 + i * size, size, size));
                    }
                    else if (map[i, j] == 4)
                    {
                        //e.FillRectangle(Brushes.Green, new Rectangle(50 + j * size, 50 + i * size, size, size));
                        e.FillRectangle(tBrushGreenCase, new Rectangle(50 + j * size, 50 + i * size, size, size));
                    }
                    else if (map[i, j] == 0)
                    {
                        //    e.FillRectangle(Brushes.Gray, new Rectangle(50 + j * size, 50 + i * size, size, size));
                        e.FillRectangle(tBrushFloor, new Rectangle(50 + j * size, 50 + i * size, size, size));
                    }
                    if (greyCases == 0)
                    {
                        buttonToMainMenu.Visible = true;
                        if (path == @"Lvl\Lvl1.txt")
                        {
                            if (record[0] > kolvoSteps)
                            {
                                record[0] = kolvoSteps;
                                using (StreamWriter sw = new StreamWriter(pathToRecord))
                                {
                                    foreach(var record in record)
                                    {
                                        sw.WriteLine(record);
                                    }
                                }
                                MessageBox.Show("Ура, Вы поставили новый рекорд!");
                            }
                        }
                        else if(path == @"Lvl\Lvl2.txt")
                        {
                            if(record[1] > kolvoSteps)
                            {
                                record[1] = kolvoSteps;
                                using (StreamWriter sw = new StreamWriter(pathToRecord))
                                {
                                    foreach (var record in record)
                                    {
                                        sw.WriteLine(record);
                                    }
                                }
                                MessageBox.Show("Ура, Вы поставили новый рекорд!");
                            }
                        }
                        else if (path == @"Lvl\Lvl3.txt")
                        {
                            if(record[2] > kolvoSteps)
                            {
                                record[2] = kolvoSteps;
                                using (StreamWriter sw = new StreamWriter(pathToRecord))
                                {
                                    foreach (var record in record)
                                    {
                                        sw.WriteLine(record);
                                    }
                                }
                                MessageBox.Show("Ура, Вы поставили новый рекорд!");
                            }
                        }
                        else if (path == @"Lvl\Lvl4.txt")
                        {
                            if(record[3] > kolvoSteps)
                            {
                                record[3] = kolvoSteps;
                                using (StreamWriter sw = new StreamWriter(pathToRecord))
                                {
                                    foreach (var record in record)
                                    {
                                        sw.WriteLine(record);
                                    }
                                }
                                MessageBox.Show("Ура, Вы поставили новый рекорд!");
                            }
                        }
                        else if (path == @"Lvl\Lvl5.txt")
                        {
                            if(record[4] > kolvoSteps)
                            {
                                record[4] = kolvoSteps;
                                using (StreamWriter sw = new StreamWriter(pathToRecord))
                                {
                                    foreach (var record in record)
                                    {
                                        sw.WriteLine(record);
                                    }
                                }
                                MessageBox.Show("Ура, Вы поставили новый рекорд!");
                            }
                        }
                    }
                }
            }
        }

        public void DrawGrid(Graphics g)
        {
            for(int i = 0; i <= height; i++)
            {
                g.DrawLine(Pens.Black, new Point(50, 50+i*size), new Point(50 + width * size ,50+i*size));
            }
            for (int i = 0; i <= width; i++)
            {
                g.DrawLine(Pens.Black, new Point(50 + i * size, 50), new Point(50 + i * size, 50 + height * size));
            }
        }
        public void findStartPos(int[,]a, int element)
        {

            for (int i = 0; i < height; i++)
            {
                for (int j = 0; j < width; j++)
                {
                    if (a[i, j] == element)
                    {
                        currentX = i;
                        currentY = j;
                    }
                }
            }
        }
        public static int findElement(int[,] a, int element)
        {
            int n = 0;
            for (int i = 0; i < height; i++)
            {
                for (int j = 0; j < width; j++)
                {
                    if (a[i, j] == element)
                    {
                        n++;
                    }
                }
            }
            return n;
        }

        private void buttonToMainMenu_Click(object sender, EventArgs e)
        {
            this.Close();
            th = new Thread(open);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
        }

        public void open(object obj)
        {
            Application.Run(new Form1());
        }

        private void OnPaint(object sender, PaintEventArgs e)
        {
            //DrawGrid(e.Graphics);
            DrawMap(e.Graphics);
        }

        private void buttonAgain_Click(object sender, EventArgs e)
        {
                Init();
        }
    }
}
