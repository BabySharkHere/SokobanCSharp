﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        Thread th;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, System.EventArgs e)
        {
            if (comboBox1.SelectedIndex > -1)
            {
                this.Close();
                th = new Thread(open);
                th.SetApartmentState(ApartmentState.STA);
                th.Start();
            }
            else
            {
                MessageBox.Show("Выберите, пожалуйста, уровень");
            }
        }

        public void open(object obj)
        {
            Application.Run(new Form2());
        }

        private void buttonSelect_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex > -1)
            {
                switch (comboBox1.SelectedIndex)
                {
                    case 0:
                        {
                            Form2.path = @"Lvl\Lvl1.txt";
                            break;
                        }
                    case 1:
                        {
                            Form2.path = @"Lvl\Lvl2.txt";
                            break;
                        }
                    case 2:
                        {
                            Form2.path = @"Lvl\Lvl3.txt";
                            break;
                        }
                    case 3:
                        {
                            Form2.path = @"Lvl\Lvl4.txt";
                            break;
                        }
                    case 4:
                        {
                            Form2.path = @"Lvl\Lvl5.txt";
                            break;
                        }
                }
            }
            else 
            {
                MessageBox.Show("Выберите, пожалуйста, уровень");
            }
        }

        private void buttonRecord_Click(object sender, EventArgs e)
        {
            this.Close();
            th = new Thread(openForm3);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
        }

        public void openForm3(object obj)
        {
            Application.Run(new Form3());
        }

        private void buttonHelp_Click(object sender, EventArgs e)
        {
            this.Close();
            th = new Thread(openFormHelp);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
        }

        public void openFormHelp(object obj)
        {
            Application.Run(new FormHelp());
        }
    }
}
