﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class FormHelp : Form
    {
        Thread th;
        public FormHelp()
        {
            InitializeComponent();
            updateTextBox();
        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            this.Close();
            th = new Thread(open);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
        }
        public void open(object obj)
        {
            Application.Run(new Form1());
        }

        public void updateTextBox()
        {
            richTextBoxHelp.Text = richTextBoxHelp.Text + "Здравствуйте, это игра 'Сокобан'.\n\nПравила этой игры очень просты. Игрок -- тот самый человечек, толкает ящики с сундуку(точке сбора). Как только ящиков на карте не останется, вы сможете выйти в главное меню и перейти на следующий уровень.\n\nP.S.::Через стены проходить нельзя, ящики толкать через стены нельзя. Вы всегда можете начать новую попытку, нажав кнопку 'Начать заново'.\n\nЕщё один P.S.:: В меню рекордов Вы можете увидеть рекордное количество шагов на всех уровнях(чем меньше шагов затрачено, тем лучше). Изначально оно равно 100.000\n\n\nУдачной игры!";
        }
    }
}
