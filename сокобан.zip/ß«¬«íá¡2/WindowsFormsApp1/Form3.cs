﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form3 : Form
    {
        Thread th;

        int[] record;
        public Form3()
        {
            InitializeComponent();
            readRecord();
            textBoxUpdate(record);
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
            th = new Thread(open);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
        }
        public void open(object obj)
        {
            Application.Run(new Form1());
        }

        public void readRecord()
        {
            string pathToRecord = @"record.txt";
            StreamReader file = new StreamReader(pathToRecord);
            string s = file.ReadToEnd();
            file.Close();
            string[] stolb = s.Split('\n');
            record = new int[stolb.Length - 1];
            int t = 0;
            for (int i = 0; i < stolb.Length - 1; i++)
            {
                t = Convert.ToInt32(stolb[i]);
                record[i] = t;
            }
        }
        public void textBoxUpdate(int[] record)
        {
            int t = 0;
            richTextBoxRecord.Clear();
            richTextBoxRecord.Text = richTextBoxRecord.Text + "Рекорды: \n\n\n";
            richTextBoxRecord.Text = richTextBoxRecord.Text + "|  LVL\t|Количество шагов\n";
            for (int i = 0; i < record.Length; i++)
            {
                t = i + 1;
                richTextBoxRecord.Text = richTextBoxRecord.Text + "|\t" + t + "\t|\t" + record[i] + "\t|\n";
            }
            //richTextBoxRecord.Text = richTextBoxRecord.Text + "\n\n";
            //for (int i = 0; i < record.Length; i++)
            //{
            //    richTextBoxRecord.Text = richTextBoxRecord.Text + "\t" + record[i];
            //}
            richTextBoxRecord.Text = richTextBoxRecord.Text + "\n\n\nПервый столбец - уровни\nВторой - рекордное количество шагов";
            //richTextBoxRecord.Text = richTextBoxRecord.Text + "\t" + record[0] + "\t|" + "\t" + record[1] + "\t|" + record[2] + "\t" + record[3] + "\t" + record[4] + "\t";
            //richTextBoxRecord.Text = richTextBoxRecord.Text + "Количество шагов: " + record[1];
        }

        private void Form3_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
